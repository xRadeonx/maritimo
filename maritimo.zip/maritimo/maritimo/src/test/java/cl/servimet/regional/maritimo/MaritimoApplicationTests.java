package cl.servimet.regional.maritimo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MaritimoApplicationTests {

	@Test
	void contextLoads() {
	}

}
